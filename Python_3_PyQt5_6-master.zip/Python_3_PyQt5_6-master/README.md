﻿# Python_3_PyQt5_6
**Работа с графикой в Python**

![Screenshot](screenshot.png)