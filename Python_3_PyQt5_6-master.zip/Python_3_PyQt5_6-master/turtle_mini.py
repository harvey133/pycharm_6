import turtle

turtle.fillcolor("#9e693d")
turtle.begin_fill()

turtle.forward(100)

turtle.right(90)
turtle.forward(100)

turtle.right(90)
turtle.forward(100)

turtle.right(90)
turtle.forward(100)

turtle.up()
turtle.goto(0, -50)
turtle.down()

turtle.end_fill()

turtle.color("yellow")
turtle.begin_fill()
turtle.circle(60)
turtle.down()

turtle.end_fill()

turtle.done()
